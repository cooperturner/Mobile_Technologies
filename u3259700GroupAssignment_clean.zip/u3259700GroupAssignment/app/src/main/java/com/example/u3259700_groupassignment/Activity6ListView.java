package com.example.u3259700_groupassignment;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Activity6ListView extends AppCompatActivity {

    private ListView listView;
    private Button btnAdd;
    private List<ListItem> itemList;
    private ListAdapter adapter;
    private DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity6_list_view);

        listView = findViewById(R.id.listView);
        btnAdd = findViewById(R.id.btnAdd);

        itemList = new ArrayList<>();
        adapter = new ListAdapter(this, R.layout.list_item, itemList);
        listView.setAdapter(adapter);

        db = FirebaseDatabase.getInstance().getReference("Storage");

        loadFromFirebase();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            ListItem selected = itemList.get(position);
            Intent intent = new Intent(Activity6ListView.this, Activity7.class);
            intent.putExtra("firebaseKey", selected.getKey());
            intent.putExtra("readerText", selected.getReader());
            intent.putExtra("resultText", selected.getText());
            intent.putExtra("filename", selected.getFilename());
            startActivity(intent);
        });

        btnAdd.setOnClickListener(v ->
                startActivity(new Intent(Activity6ListView.this, MainActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFromFirebase();
    }

    private void loadFromFirebase() {
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                itemList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String key = child.getKey();
                    String filename = child.child("filename").getValue(String.class);
                    String reader = child.child("reader").getValue(String.class);
                    String text = child.child("text").getValue(String.class);

                    ListItem item = new ListItem(key, filename, reader, text);

                    if (filename != null) {
                        try {
                            Uri imageUri = loadImageFromGallery(filename);
                            item.setImageUri(imageUri);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    itemList.add(item);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(Activity6ListView.this,
                        "Failed to load: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Uri loadImageFromGallery(String filename) throws IOException {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME
        };
        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        String[] selectionArgs = {filename};

        try (Cursor cursor = getContentResolver().query(
                uri, projection, selection, selectionArgs, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idColumn = cursor.getColumnIndexOrThrow(
                        MediaStore.Images.Media._ID);
                long imageId = cursor.getLong(idColumn);
                return ContentUris.withAppendedId(uri, imageId);
            }
        }
        return null;
    }
}