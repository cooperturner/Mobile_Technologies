package com.example.u3259700_groupassignment;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;

public class Activity2 extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_GALLERY_PERMISSION = 101;

    private ImageView imageView;
    private TextView tvTitle, tvResults;
    private Button btnOpenCamera, btnLoadImage, btnEditResults;

    private int selectedReader = 1;
    private Uri imageFileUri;

    private ActivityResultLauncher<Intent> activityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        imageView = findViewById(R.id.imageView);
        tvTitle = findViewById(R.id.tvTitle);
        tvResults = findViewById(R.id.tvResults);
        btnOpenCamera = findViewById(R.id.btnOpenCamera);
        btnLoadImage = findViewById(R.id.btnLoadImage);
        btnEditResults = findViewById(R.id.btnEditResults);

        selectedReader = getIntent().getIntExtra("selectedReader", 1);
        setReaderTitle(selectedReader);
        setReaderImage(selectedReader);

        // Register ActivityResultLauncher — lecturer's exact pattern
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        if (result.getData() != null &&
                                result.getData().getData() != null) {
                            imageFileUri = result.getData().getData();
                        }
                        // Display image using URI directly
                        imageView.setImageURI(imageFileUri);

                        // Run ML Kit on the image
                        tvResults.setText("Analyzing...");
                        InputImage image = null;
                        try {
                            image = InputImage.fromFilePath(
                                    getBaseContext(), imageFileUri);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (image != null) {
                            runMLKitAnalysis(image);
                        }
                    }
                });

        btnOpenCamera.setOnClickListener(v -> openCamera());
        btnLoadImage.setOnClickListener(v -> loadImage());

        btnEditResults.setOnClickListener(v -> {
            if (imageFileUri == null) {
                Toast.makeText(this, "Please take or load an image first",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Activity2.this, Activity5.class);
            intent.putExtra("readerText", tvTitle.getText().toString());
            intent.putExtra("resultText", tvResults.getText().toString());
            intent.putExtra("imageUri", imageFileUri.toString());
            intent.putExtra("isNew", true);
            startActivity(intent);
        });
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION);
            return;
        }
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    private void loadImage() {
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        activityResultLauncher.launch(galleryIntent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            Toast.makeText(this, "Camera permission denied",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void setReaderTitle(int reader) {
        if (reader == 1) tvTitle.setText("Barcode Reader");
        else if (reader == 2) tvTitle.setText("Content Reader");
        else tvTitle.setText("Text Reader");
    }

    private void setReaderImage(int reader) {
        if (reader == 1) imageView.setImageResource(R.drawable.barcode);
        else if (reader == 2) imageView.setImageResource(R.drawable.content);
        else imageView.setImageResource(R.drawable.text);
    }

    private void runMLKitAnalysis(InputImage image) {
        tvResults.setText("");
        if (selectedReader == 1) {
            runBarcodeReader(image);
        } else if (selectedReader == 2) {
            runContentReader(image);
        } else {
            runTextReader(image);
        }
    }

    private void runBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    tvResults.append(Html.fromHtml(
                            "<font color='navy'><b>Detected barcode:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    String last = "";
                    for (Barcode barcode : barcodes) {
                        last = barcode.getRawValue();
                        tvResults.append(last + "\n");
                    }
                    if (last.length() < 2) {
                        tvResults.append("Barcode not found.\n");
                    }
                })
                .addOnFailureListener(e ->
                        tvResults.setText("Barcode scan failed: " + e.getMessage()));
    }

    private void runContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(
                ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        tvResults.append("Nothing found in the image\n");
                        return;
                    }
                    tvResults.append(Html.fromHtml(
                            "<font color='navy'><b>Recognised image content:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        String text = label.getText();
                        float confidence = label.getConfidence();
                        tvResults.append(counter + ". " + text +
                                " (" + String.format("%.1f", confidence * 100.0f)
                                + "% confidence)\n");
                        counter++;
                    }
                })
                .addOnFailureListener(e ->
                        tvResults.setText("Content recognition failed: " + e.getMessage()));
    }

    private void runTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    tvResults.append(Html.fromHtml(
                            "<font color='navy'><b>Extracted text:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    String text = visionText.getText();
                    if (text.length() > 1) {
                        tvResults.append(text + "\n");
                    } else {
                        tvResults.append("No text found.\n");
                    }
                })
                .addOnFailureListener(e ->
                        tvResults.setText("Text recognition failed: " + e.getMessage()));
    }
}