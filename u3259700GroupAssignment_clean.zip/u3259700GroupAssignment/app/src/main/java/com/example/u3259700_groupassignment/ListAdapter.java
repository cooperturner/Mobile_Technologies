package com.example.u3259700_groupassignment;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ListAdapter extends ArrayAdapter<ListItem> {

    private final List<ListItem> items;

    public ListAdapter(@NonNull Context context, int resource,
                       @NonNull List<ListItem> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item, parent, false);
        }

        convertView.setBackgroundColor(
                position % 2 == 0 ? Color.WHITE : Color.LTGRAY);

        ListItem item = items.get(position);

        ImageView imageView = convertView.findViewById(R.id.imageViewListItem);
        TextView textViewItem = convertView.findViewById(R.id.textViewItem);
        TextView textViewSubItem = convertView.findViewById(R.id.textViewSubItem);

        textViewItem.setText(item.getReader());
        textViewSubItem.setText(item.getText() != null
                ? item.getText().replaceAll("\n", " ") : "");

        if (item.getImageUri() != null) {
            imageView.setImageURI(item.getImageUri());
        } else {
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        return convertView;
    }
}