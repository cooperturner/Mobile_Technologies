package com.example.u3259700_groupassignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageButton imageButton1, imageButton2, imageButton3;
    private Button btnListOfAnalysedImages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton1 = findViewById(R.id.imageButton1);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton3 = findViewById(R.id.imageButton3);
        btnListOfAnalysedImages = findViewById(R.id.btnListOfAnalysedImages);

        imageButton1.setOnClickListener(v -> openActivity2(1));
        imageButton2.setOnClickListener(v -> openActivity2(2));
        imageButton3.setOnClickListener(v -> openActivity2(3));

        btnListOfAnalysedImages.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, Activity6ListView.class))
        );
    }

    private void openActivity2(int selectedReader) {
        Intent intent = new Intent(MainActivity.this, Activity2.class);
        intent.putExtra("selectedReader", selectedReader);
        startActivity(intent);
    }
}