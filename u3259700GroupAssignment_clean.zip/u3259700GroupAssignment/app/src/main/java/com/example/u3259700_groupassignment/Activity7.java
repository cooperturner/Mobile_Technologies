package com.example.u3259700_groupassignment;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;

public class Activity7 extends AppCompatActivity {

    private TextView tvReader, tvResults;
    private ImageView imageView;
    private Button btnEdit, btnDelete, btnCancel;

    private String firebaseKey;
    private String readerText;
    private String resultText;
    private String filename;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);

        tvReader = findViewById(R.id.tvReader);
        tvResults = findViewById(R.id.tvResults);
        imageView = findViewById(R.id.imageView);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        btnCancel = findViewById(R.id.btnCancel);

        // Get data passed from Activity 6
        Intent intent = getIntent();
        firebaseKey = intent.getStringExtra("firebaseKey");
        readerText = intent.getStringExtra("readerText");
        resultText = intent.getStringExtra("resultText");
        filename = intent.getStringExtra("filename");

        tvReader.setText(readerText);
        tvResults.setText(resultText);

        // Load image from gallery using the filename stored in Firebase
        if (filename != null) {
            try {
                imageUri = loadImageFromGallery(filename);
                if (imageUri != null) {
                    imageView.setImageURI(imageUri);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Edit button — open Activity 5 with all existing item data
        btnEdit.setOnClickListener(v -> {
            Intent editIntent = new Intent(Activity7.this, Activity5.class);
            editIntent.putExtra("readerText", readerText);
            editIntent.putExtra("resultText", resultText);
            editIntent.putExtra("filename", filename);
            editIntent.putExtra("isNew", false);
            editIntent.putExtra("firebaseKey", firebaseKey);
            // Pass the resolved URI so Activity 5 can display the image
            if (imageUri != null) {
                editIntent.putExtra("imageUri", imageUri.toString());
            }
            startActivity(editIntent);
        });

        // Delete button — remove from Firebase then show updated list on Activity 6
        btnDelete.setOnClickListener(v -> {
            DatabaseReference db = FirebaseDatabase.getInstance()
                    .getReference("Storage");
            db.child(firebaseKey).removeValue()
                    .addOnSuccessListener(unused -> {
                        Toast.makeText(this, "Deleted successfully",
                                Toast.LENGTH_SHORT).show();
                        goToActivity6();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Delete failed: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show());
        });

        // Cancel button — go back to Activity 6 with no changes
        btnCancel.setOnClickListener(v -> goToActivity6());
    }

    private void goToActivity6() {
        Intent intent = new Intent(Activity7.this, Activity6ListView.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    private Uri loadImageFromGallery(String filename) throws IOException {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME
        };
        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        String[] selectionArgs = {filename};

        try (Cursor cursor = getContentResolver().query(
                uri, projection, selection, selectionArgs, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idColumn = cursor.getColumnIndexOrThrow(
                        MediaStore.Images.Media._ID);
                long imageId = cursor.getLong(idColumn);
                return ContentUris.withAppendedId(uri, imageId);
            }
        }
        return null;
    }
}