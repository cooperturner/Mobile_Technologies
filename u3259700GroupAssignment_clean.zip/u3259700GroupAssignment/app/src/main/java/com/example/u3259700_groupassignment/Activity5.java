package com.example.u3259700_groupassignment;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class Activity5 extends AppCompatActivity {

    private EditText etReader, etResults;
    private ImageView imageView;
    private Button btnSave;

    private Uri imageFileUri;
    private boolean isNew;
    private String firebaseKey;
    private String existingFilename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);

        etReader = findViewById(R.id.etReader);
        etResults = findViewById(R.id.etResults);
        imageView = findViewById(R.id.imageView);
        btnSave = findViewById(R.id.btnSave);

        Intent intent = getIntent();
        etReader.setText(intent.getStringExtra("readerText"));
        etResults.setText(intent.getStringExtra("resultText"));

        String imageUriString = intent.getStringExtra("imageUri");
        imageFileUri = imageUriString != null ? Uri.parse(imageUriString) : null;

        isNew = intent.getBooleanExtra("isNew", true);
        firebaseKey = intent.getStringExtra("firebaseKey");
        existingFilename = intent.getStringExtra("filename");

        if (imageFileUri != null) {
            imageView.setImageURI(imageFileUri);
        }

        btnSave.setOnClickListener(v -> saveData());
    }

    public void saveData() {
        String readerText = etReader.getText().toString().trim();
        String resultText = etResults.getText().toString().trim();

        if (readerText.isEmpty() || resultText.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Storage");

        Map<String, Object> data = new HashMap<>();
        data.put("reader", readerText);
        data.put("text", resultText);

        if (isNew) {
            // New item: save image to gallery with a unique filename
            String imageFilename = System.currentTimeMillis() + ".png";
            if (imageFileUri != null) {
                Bitmap bitmap = getBitmapFromUri(imageFileUri);
                if (bitmap != null) {
                    saveImageToGallery(bitmap, imageFilename, this);
                }
            }
            data.put("filename", imageFilename);
            db.push().setValue(data)
                    .addOnSuccessListener(unused -> goToActivity6())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Save failed: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show());
        } else {
            // Existing item: keep original filename, only update text fields
            data.put("filename", existingFilename);
            db.child(firebaseKey).updateChildren(data)
                    .addOnSuccessListener(unused -> goToActivity6())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Update failed: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show());
        }
    }

    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ImageDecoder.Source source =
                    ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source);
        } catch (IOException e) {
            Log.e("URI_TO_BITMAP", "Failed to load image", e);
            return null;
        }
    }

    private void saveImageToGallery(Bitmap bitmap, String fileName, Context context) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);

        Uri imageUri = context.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        try {
            OutputStream outputStream =
                    context.getContentResolver().openOutputStream(imageUri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
            Log.d("SAVE_GALLERY", "Image saved: " + imageUri.toString());
        } catch (IOException e) {
            Log.e("SAVE_GALLERY", "Error saving image", e);
        }
    }

    private void goToActivity6() {
        Intent intent = new Intent(Activity5.this, Activity6ListView.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}